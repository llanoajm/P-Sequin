'''
File configured by CMake
Can include any CMake variables that are desired within the Python package
'''

version = '4.0.0.23'
build_type = 'Release'
