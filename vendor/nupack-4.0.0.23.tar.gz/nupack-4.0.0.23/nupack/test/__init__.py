
'''
The following is used to import the top-level nupack module
no matter what name it is actually called.

Test modules should just
- import the 'nu' name from here
- import using import_nupack('name.of.submodule')
'''

import nupack

